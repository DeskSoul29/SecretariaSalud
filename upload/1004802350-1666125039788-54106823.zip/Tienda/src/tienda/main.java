package tienda;

public class main {


    public static void main(String[] args) {
        Catalogo ct=new Catalogo();
        ct.setVisible(true);   
    }
    
}
